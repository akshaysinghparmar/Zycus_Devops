# Deploy and configure Kafka topics for Strimzi Operator

## Requirements
Install Kafka with the kafka helm chart first.
