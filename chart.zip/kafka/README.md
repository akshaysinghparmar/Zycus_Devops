# Deploy and configure Kafka cluster via Strimzi Operator

## Requirements
Deploy the latest [Strimzi Operator](https://strimzi.io/docs/operators/latest/deploying.html#deploying-cluster-operator-str) to the project namespace.  

## Installation
Use this helm repository to install the kafka cluster resources.
