# Deploy and configure Kafka users for Strimzi Operator

## Requirements
Install Kafka with the kafka helm chart first.
